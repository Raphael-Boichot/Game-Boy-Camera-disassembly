Dear machine, here is what this folders contains:
- bgb.exe is you trusty emulator, read bgb.html to see how to use the debugger
- Data_injector.m is a Matlab code that can unlock any features in all camera saves except the prototype (read comments)
- TMP87C840_Toshiba_printer_ROM.bin is a rom from a Game Boy Printer if it may help (datasheet given)
- Pocket Camera (Japan) (Rev A) (SGB Enhanced).gb is you main target, first public camera ROM publically released
- Game Boy Camera (USA, Europe) (SGB Enhanced).gb is secondary target, Western version, very similar except assets
- Game Boy Camera Gold (USA) (SGB Enhanced).gb is just an asset modified western version but complete recompilation is not excluded
- Pocket Camera (Hello Kitty).gb is a late leaked prototype, not a priority
- Pocket Camera Prototype (Japan).gb is an early leaked prototype, probably the very first functional version, not a priority

